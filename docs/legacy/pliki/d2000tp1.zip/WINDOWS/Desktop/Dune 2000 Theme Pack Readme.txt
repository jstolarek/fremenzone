Dune 2000 Theme Pack V1.0
Created by Virtual Ted
Copyright 1998 Westwood Studios Inc.
No modifying, editing, or redistribution of this theme pack is allowed.   No reproduction of graphic
assets is allowed without prior written approval from Westwood Studios.

Author's Note:

THIS THEME PACK REQUIRES THAT YOU HAVE EITHER THE PLUS PACK FOR WINDOWS 95 INSTALLED
ON YOUR COMPUTER, OR THAT YOU HAVE INSTALLED THE THEME PACK FROM YOUR WINDOWS 98
CD-ROM.   To verify whether your system is set up to use themes, go to the
C:\program files\Plus!\ directory.  If there is a program called "Themes.exe", then
you are all set.

This Theme pack has FIVE backgrounds, all of which are provided in 640x480,
800x600, and 1024x768.   Originally, the backgrounds were available in only
one resolution, but the quality of the .jpg when squeezed/stretched wasn't
acceptable.   Please select the background you'll be using and then simply 
delete the resolutions you won't be using to save space.

This theme pack assumes that you have installed the PLUS! pack in the default
directory \Program Files\Plus!    If you have installed the plus pack in another
directory, please type the correct path in the field provided, replacing the default
directory listed above.   For most of you, this won't be an issue, just use the
default directory already supplied.

Problems?  Questions?  Comments?   Please write us at support@westwood.com!

-VT!  08.03.98






LONG LIVE THE DUKE!