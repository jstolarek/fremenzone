Behind the Dune
===============

Żeby odblokować scenki w galerii w menu skopiuj plik DuneV2-22.sol do:

C:\Users\<użytkownik>\AppData\Roaming\Macromedia\Flash Player\#SharedObjects\S5DYNS3C\localhost\<scieżka>\<do>\<gry>\BehindTheDune.exe\

gdzie:

  * <użytkownik> to folder odpowiadający twojej nazwie uzytkownika
  * <S5DYNS3C> to identyfikator, który na twojej maszynie może być inny
  * <scieżka>\<do>\<gry> to zagnieżdżone w sobie foldery odpowiadające ścieżce z
    której uruchomiona została gra

Plik stworzony dla gry w wersji 2.35.

Info
====

Plik ściągnięty ze strony www.fremenzone.pl
